//
//  AddListDataViewController.swift
//  Project Task
//
//  Created by Kaustubh Rastogi on 21/03/23.
//

import UIKit
import IQKeyboardManagerSwift

class AddListDataViewController: UIViewController {

    @IBOutlet weak var DescTextField: UITextField!
    @IBOutlet weak var labelHeading: UILabel!
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var textFieldPrice: UITextField!
   
    @IBOutlet weak var textfieldCat: UITextField!
    @IBOutlet weak var textfildTitle: UITextField!
    @IBOutlet weak var img: UIImageView!
    
    var product: ListData?
    var addModel : AddUpdateViewModel = AddUpdateViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        imagedata()
        productdata()
        
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        guard let headerView = tableview.tableHeaderView else {
            return
        }
        let size = headerView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize)
        if headerView.frame.size.height != size.height {
            headerView.frame.size.height = size.height
            tableview.tableHeaderView = headerView
            tableview.layoutIfNeeded()
        }
        
    }
    
    func didEnter(){
        let price = self.textFieldPrice.text ?? ""
        let cat = self.textfieldCat.text ?? ""
        let ttle = self.textfildTitle.text ?? ""
        let desc = self.DescTextField.text ?? ""
        addModel.doAdd(title: ttle, price: price, desc: desc, cat: cat)
        addModel.callBack = { [weak self] in
            DispatchQueue.main.async {
                for controller in (self?.navigationController!.viewControllers)! as Array {
                    if controller.isKind(of: ListViewController.self) {
                        self?.navigationController!.popToViewController(controller, animated: true)
                       
                        return
                    }
                }
                
            }
        }
    }
    
    @IBAction func buttonBone(_ sender: UIButton) {
        didEnter()
        
    }
    
    

    
    func imagedata(){
        img.layer.cornerRadius = 5
        img.layer.borderColor = UIColor.darkGray.cgColor
        img.layer.borderWidth = 1
       
    }

    func productdata(){
        guard let title = product?.title ,
              let cat = product?.category,
                let desc = product?.description,
              let price = product?.price else {
            return
        }
        self.labelHeading.text = "Update Product"
        self.textfildTitle.text = title
        self.DescTextField.text =  desc
        self.textfieldCat.text = cat
        self.textFieldPrice.text = "\(price)"
        img.downlodeImage(serviceurl: product?.image ?? "", placeHolder: UIImage(named: ""))
    }
    
    
    

}
