//
//  ListDataViewModel.swift
//  Project Task
//
//  Created by Kaustubh Rastogi on 21/03/23.
//

import Foundation





class ListViewModel : NSObject{
    var reloadTableView: (() -> Void)?
    
    var list = [ListData](){
        didSet{
            reloadTableView?()
        }
    }
    
    
    
   
    
    
    func listProduct() {
        guard let url = URL(string: "https://fakestoreapi.com/products") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        request.allHTTPHeaderFields = [
            "Content-Type": "application/json"
        ]

        URLSession.shared.dataTask(with: request) { data, response, error in
          
            do {
              
                let response = try JSONDecoder().decode([ListData].self, from: data!)
                self.list = response
                print(self.list)
            }catch {
                print(error)
            }
        }.resume()
    }
    
}

extension ListViewModel {
    
    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case newProductAdded(product: AddListData)
    }
    
}
