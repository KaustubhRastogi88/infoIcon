//
//  AddListData.swift
//  Project Task
//
//  Created by Kaustubh Rastogi on 21/03/23.
//

import Foundation


struct AddListData: Codable {
    var id: Int? = nil
    var title: String
    var price: String
    var description:String
    var category : String
}
