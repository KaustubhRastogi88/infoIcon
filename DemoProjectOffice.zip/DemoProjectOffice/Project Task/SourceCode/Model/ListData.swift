//
//  ListData.swift
//  Project Task
//
//  Created by Kaustubh Rastogi on 21/03/23.
//

import Foundation

struct ListData: Codable {
    var id: Int
    var description: String
    var category: String
    var title: String
    var price: Double
    var image: String
    var rating: Rate
}

struct Rate: Codable {
    var rate: Double
    var count: Int
}
